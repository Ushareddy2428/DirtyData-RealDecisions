﻿import nbformat as nbf

nb = nbf.v4.new_notebook()

cells = []

# Title & Intro
cells.append(nbf.v4.new_markdown_cell("""# Problem 2: Dirty Data, Real Decisions
### Case Management System Data Quality Audit & Operational Investigation (2023–2025)
**Author**: Analytics & Data Quality Engineering Team  
**Dataset**: `case-export-2023-2025.csv` (15,100 raw records)  

---
## Executive Summary
This notebook delivers a comprehensive data quality assessment of a legacy case management export and rigorously investigates three operational questions posed by program leadership regarding case closure time drift.
"""))

# Setup Code
cells.append(nbf.v4.new_code_cell("""import os
import sys
import json
import re
import pandas as pd
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt

plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['figure.dpi'] = 150

RAW_CSV = os.path.join('data pack', 'case-export-2023-2025.csv')
raw_df = pd.read_csv(RAW_CSV, dtype=str)
print(f"Loaded raw export: {len(raw_df):,} records across {len(raw_df.columns)} columns.")
"""))

# Section 1: Data Quality Audit
cells.append(nbf.v4.new_markdown_cell("""## 1. Data Quality Audit & Diagnostics

We evaluate 5 critical dimensions of data quality:
1. **Identifier Integrity**: Duplicate identity through case formatting variations (900 pairs).
2. **Date Serialization**: Multi-locale date formats and temporal contradictions.
3. **Categorical Free-Text Drift**: Uncontrolled terminology for case categories.
4. **Attribute Missingness**: Structural missingness in the `priority` field (100% missing pre-March 2024).
5. **Censoring**: Right-censored open cases in 2025 (751 cases).
"""))

cells.append(nbf.v4.new_code_cell("""# 1. Missingness Audit
missing_df = pd.DataFrame({
    'Missing Count': raw_df.isna().sum(),
    'Missing Pct (%)': (raw_df.isna().sum() / len(raw_df)) * 100
})
display(missing_df)

# 2. Duplicate Identification
raw_df['norm_id'] = raw_df['case_id'].str.upper().str.replace(r'[^A-Z0-9]', '', regex=True)
dup_mask = raw_df.duplicated(subset=['norm_id'], keep=False)
print(f"Total duplicate rows: {dup_mask.sum():,} representing {raw_df[dup_mask]['norm_id'].nunique():,} unique case IDs.")

# 3. Category Free-Text Diversity
print(f"Unique raw category strings: {raw_df['category'].nunique()}")
display(raw_df['category'].value_counts().head(15))
"""))

# Section 2: Cleaning Pipeline
cells.append(nbf.v4.new_markdown_cell("""## 2. Deterministic Cleaning Pipeline

We apply deterministic rules to clean and standardize the data, tracking every dropped row in an audit log:
- Canonical deduplication by alphanumeric case ID, retaining max contact count.
- Reconciliation of all 40 category variants into 5 standard categories.
- Exclusion of 546 impossible records where closure precedes intake (including the 2024-07-01 batch artifact).
"""))

cells.append(nbf.v4.new_code_cell("""CATEGORY_MAP = {
    'Standard': 'Standard', 'routine': 'Standard', 'standard - no issues': 'Standard',
    'normal': 'Standard', 'Standard case': 'Standard', 'std': 'Standard', 'Std.': 'Standard',
    'standard': 'Standard', 'STANDARD': 'Standard',
    'Complex': 'Complex', 'complex case': 'Complex', 'COMPLEX': 'Complex', 'multi-agency': 'Complex',
    'complicated': 'Complex', 'cmplx': 'Complex', 'Complex - multi agency': 'Complex',
    'Complex (referred)': 'Complex', 'complex': 'Complex',
    'Expedited': 'Expedited', 'exp': 'Expedited', 'rush': 'Expedited', 'expedited': 'Expedited',
    'fast track': 'Expedited', 'Expedited - urgent': 'Expedited', 'URGENT': 'Expedited', 'expedite': 'Expedited',
    'Review': 'Review', 'review': 'Review', 'Annual review': 'Review', '12 month review': 'Review',
    'rev': 'Review', 'periodic review': 'Review', 'REVIEW': 'Review',
    'Appeal': 'Appeal', 'appeals': 'Appeal', 'Appeal - panel': 'Appeal', 'APPEAL': 'Appeal',
    'app': 'Appeal', 'appeal': 'Appeal', 'panel appeal': 'Appeal'
}

df = raw_df.copy()
df['clean_id'] = df['norm_id']
df['client_ref_clean'] = df['client_ref'].str.strip().str.title()
df['intake_dt'] = pd.to_datetime(df['intake_date'], format='mixed')
df['closure_dt'] = pd.to_datetime(df['closure_date'], format='mixed')
df['contact_count_int'] = pd.to_numeric(df['contact_count'], errors='coerce')
df['category_clean'] = df['category'].map(CATEGORY_MAP)

# Deduplicate
df_sorted = df.sort_values(['clean_id', 'contact_count_int'], ascending=[True, False])
dedup_df = df_sorted.drop_duplicates(subset=['clean_id'], keep='first').copy()
dedup_df['duration'] = (dedup_df['closure_dt'] - dedup_df['intake_dt']).dt.days

# Partitions
open_cases = dedup_df[dedup_df['status'] == 'Open'].copy()
closed_cases = dedup_df[dedup_df['status'] == 'Closed'].copy()
impossible_closed = closed_cases[closed_cases['duration'] < 0].copy()
valid_closed = closed_cases[closed_cases['duration'] >= 0].copy()

valid_closed['intake_year'] = valid_closed['intake_dt'].dt.year
valid_closed['closure_year'] = valid_closed['closure_dt'].dt.year

print(f"Cleaned Partitions: Valid Closed = {len(valid_closed):,}, Valid Open = {len(open_cases):,}, Impossible Dropped = {len(impossible_closed):,}")
"""))

# Section 3: Question 1
cells.append(nbf.v4.new_markdown_cell("""## 3. Question 1: Case Closure Times Drift (2023 vs 2025)

**Question**: *Have case closure times increased between 2023 and 2025, and if so, by how much?*

We evaluate this across:
1. **Intake Cohort (Closed-only)**
2. **Completion Year**
3. **Kaplan-Meier Survival Analysis (with 95% Bootstrap CIs)**
"""))

cells.append(nbf.v4.new_code_cell("""def compute_kaplan_meier_boot(df_sub, time_col='time', event_col='event', n_boot=500):
    times = df_sub[time_col].values
    events = df_sub[event_col].values
    unique_times = np.sort(np.unique(times))
    n_at_risk = len(times)
    survival = 1.0
    km_table = []
    for t in unique_times:
        d_i = np.sum((times == t) & (events == 1))
        c_i = np.sum((times == t) & (events == 0))
        if n_at_risk > 0:
            survival *= (1.0 - d_i / n_at_risk)
        km_table.append({'time': t, 'survival': survival})
        n_at_risk -= (d_i + c_i)
    km_df = pd.DataFrame(km_table)
    med = km_df[km_df['survival'] <= 0.5]['time'].iloc[0] if len(km_df[km_df['survival'] <= 0.5]) > 0 else np.nan
    q25 = km_df[km_df['survival'] <= 0.75]['time'].iloc[0] if len(km_df[km_df['survival'] <= 0.75]) > 0 else np.nan
    q75 = km_df[km_df['survival'] <= 0.25]['time'].iloc[0] if len(km_df[km_df['survival'] <= 0.25]) > 0 else np.nan
    
    np.random.seed(42)
    boot_meds = []
    n = len(times)
    for _ in range(n_boot):
        idx = np.random.randint(0, n, size=n)
        bt = times[idx]
        be = events[idx]
        bu = np.sort(np.unique(bt))
        bn = n
        bs = 1.0
        bm = np.nan
        for b_val in bu:
            bd = np.sum((bt == b_val) & (be == 1))
            bc = np.sum((bt == b_val) & (be == 0))
            if bn > 0:
                bs *= (1.0 - bd / bn)
            if bs <= 0.5:
                bm = b_val
                break
            bn -= (bd + bc)
        if not np.isnan(bm):
            boot_meds.append(bm)
    ci_low = np.percentile(boot_meds, 2.5) if len(boot_meds) > 0 else np.nan
    ci_high = np.percentile(boot_meds, 97.5) if len(boot_meds) > 0 else np.nan
    return km_df, med, q25, q75, (ci_low, ci_high)

study_end = pd.to_datetime('2025-12-31')
surv_df = dedup_df[~((dedup_df['status'] == 'Closed') & (dedup_df['closure_dt'] < dedup_df['intake_dt']))].copy()
surv_df['event'] = (surv_df['status'] == 'Closed').astype(int)
surv_df['time'] = np.where(surv_df['event'] == 1, (surv_df['closure_dt'] - surv_df['intake_dt']).dt.days, (study_end - surv_df['intake_dt']).dt.days)
surv_df['intake_year'] = surv_df['intake_dt'].dt.year

q1_summary = []
km_curves = {}
for yr in [2023, 2024, 2025]:
    sub_closed = valid_closed[valid_closed['intake_year'] == yr]['duration']
    sub_surv = surv_df[surv_df['intake_year'] == yr]
    km_curve, km_med, km_q25, km_q75, km_ci = compute_kaplan_meier_boot(sub_surv, n_boot=500)
    km_curves[yr] = km_curve
    q1_summary.append({
        'Intake Year': yr,
        'Closed Cases': len(sub_closed),
        'Open (Censored)': len(sub_surv[sub_surv['event'] == 0]),
        'Cohort Mean (95% CI)': f"{sub_closed.mean():.2f} [{stats.t.interval(0.95, len(sub_closed)-1, loc=sub_closed.mean(), scale=stats.sem(sub_closed))[0]:.2f}, {stats.t.interval(0.95, len(sub_closed)-1, loc=sub_closed.mean(), scale=stats.sem(sub_closed))[1]:.2f}]",
        'Cohort Median (days)': sub_closed.median(),
        'KM Median (95% CI)': f"{km_med:.1f} [{km_ci[0]:.1f}, {km_ci[1]:.1f}]",
        'KM IQR (Adjusted)': f"[{km_q25:.0f}, {km_q75:.0f}]"
    })

display(pd.DataFrame(q1_summary))

# Plot KM Survival Curves
fig, ax = plt.subplots(figsize=(9, 5))
colors = {2023: '#1f77b4', 2024: '#ff7f0e', 2025: '#d62728'}
for yr in [2023, 2024, 2025]:
    ax.step(km_curves[yr]['time'], km_curves[yr]['survival'] * 100, where='post', label=f'Intake {yr} (KM Med = {q1_summary[yr-2023][\"KM Median (95% CI)\"]})', color=colors[yr], linewidth=2)
ax.axhline(50, color='gray', linestyle=':', label='Median (50%)')
ax.set_xlim(0, 160)
ax.set_title('Kaplan-Meier Survival Curves by Intake Cohort (Adjusted for Censoring)', fontweight='bold')
ax.set_xlabel('Days from Intake')
ax.set_ylabel('% Cases Remaining Open')
ax.legend()
plt.show()
"""))

# Section 4: Question 2
cells.append(nbf.v4.new_markdown_cell("""## 4. Question 2: Operational Localization & Geographic Attribution

**Question**: *If closure times have changed, what is driving the change?*

**Finding**: The entire system slowdown is **localized to Weybridge District** beginning in **August 2024 (Q3 2024)**. The other three districts (Ash Hill, Calder Central, Northgate) remained completely stable.

> **Operational Scope Note**: While the data conclusively proves that the slowdown is localized to Weybridge, the underlying physical operational mechanism (e.g. local staffing changes, partner delays, procedural bottlenecks) is not recorded in this export and remains unknown without an on-site audit.
"""))

cells.append(nbf.v4.new_code_cell("""valid_closed['intake_qtr'] = valid_closed['intake_dt'].dt.to_period('Q')
quarterly_dist = valid_closed.groupby(['intake_qtr', 'district'])['duration'].median().unstack()

fig, ax = plt.subplots(figsize=(10, 5.5))
for dist in quarterly_dist.columns:
    ax.plot([str(q) for q in quarterly_dist.index], quarterly_dist[dist], marker='o', linewidth=2.5 if dist=='Weybridge' else 1.5, label=dist)
ax.axvline('2024Q3', color='red', linestyle='--', label='August 2024 Shock')
ax.set_title('Quarterly Median Case Closure Duration by District', fontweight='bold')
ax.set_ylabel('Median Duration (Days)')
ax.set_xlabel('Intake Quarter')
plt.xticks(rotation=45)
ax.legend()
plt.show()

# District KM Summary with 95% CIs
dist_summary = []
for d in ['Ash Hill', 'Calder Central', 'Northgate', 'Weybridge']:
    row = {'District': d}
    for yr in [2023, 2024, 2025]:
        sub = surv_df[(surv_df['district'] == d) & (surv_df['intake_year'] == yr)]
        _, med, _, _, ci_boot = compute_kaplan_meier_boot(sub, n_boot=500)
        row[f'{yr} KM Med (95% CI)'] = f"{med:.1f} [{ci_boot[0]:.1f}, {ci_boot[1]:.1f}]"
    dist_summary.append(row)
display(pd.DataFrame(dist_summary))
"""))

# Section 5: Question 3
cells.append(nbf.v4.new_markdown_cell("""## 5. Question 3: Triage Efficacy Evaluation

**Question**: *Did the case triage process introduced during 2024 reduce closure times for high-priority cases?*

### Analytical Conclusion: THE DATA GENUINELY CANNOT ANSWER THIS QUESTION.

**Four Fatal Flaws**:
1. **Zero Pre-Intervention Baseline**: `priority` is 100% missing from Jan 2023 through Feb 2024 (5,856 cases).
2. **Missing Triage Telemetry**: No timestamp for triage date, no audit of triage execution.
3. **Zero Variance Explained**: Post-March 2024 high-priority cases have identical closure durations to medium/low cases (~37d median across all levels).
4. **Confounding by Weybridge Shock & Censoring**: Localized Weybridge collapse distorts overall macro trends.
"""))

cells.append(nbf.v4.new_code_cell("""# Priority Missingness Timeline
prio_monthly = surv_df.groupby([surv_df['intake_dt'].dt.to_period('M'), surv_df['priority'].fillna('Missing')]).size().unstack(fill_value=0)
display(prio_monthly.head(18))

# Post-March 2024 Priority Comparison
post_triage = valid_closed[valid_closed['intake_dt'] >= '2024-03-01']
prio_stats = post_triage.groupby('priority')['duration'].agg(['count', 'median', 'mean', 'std']).reset_index()
display(prio_stats)

# Category vs Priority Matrix
prio_cat_pivot = post_triage.groupby(['category_clean', 'priority'])['duration'].median().unstack()
display(prio_cat_pivot)
"""))

nb['cells'] = cells
with open('analysis_notebook.ipynb', 'w', encoding='utf-8') as f:
    nbf.write(nb, f)
print("Successfully updated analysis_notebook.ipynb")
