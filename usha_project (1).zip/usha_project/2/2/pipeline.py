﻿"""
Problem 2: Dirty Data, Real Decisions
Analytics and Data Quality Pipeline
"""
import os
import sys
import json
import re
import pandas as pd
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt

plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['figure.dpi'] = 300

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PACK_DIR = os.path.join(BASE_DIR, 'data pack')
RAW_CSV = os.path.join(DATA_PACK_DIR, 'case-export-2023-2025.csv')
OUTPUT_DIR = os.path.join(BASE_DIR, 'outputs')
FIGURES_DIR = os.path.join(BASE_DIR, 'figures')

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)

CATEGORY_MAP = {
    'Standard': 'Standard', 'routine': 'Standard', 'standard - no issues': 'Standard',
    'normal': 'Standard', 'Standard case': 'Standard', 'std': 'Standard', 'Std.': 'Standard',
    'standard': 'Standard', 'STANDARD': 'Standard',
    'Complex': 'Complex', 'complex case': 'Complex', 'COMPLEX': 'Complex', 'multi-agency': 'Complex',
    'complicated': 'Complex', 'cmplx': 'Complex', 'Complex - multi agency': 'Complex',
    'Complex (referred)': 'Complex', 'complex': 'Complex',
    'Expedited': 'Expedited', 'exp': 'Expedited', 'rush': 'Expedited', 'expedited': 'Expedited',
    'fast track': 'Expedited', 'Expedited - urgent': 'Expedited', 'URGENT': 'Expedited', 'expedite': 'Expedited',
    'Review': 'Review', 'review': 'Review', 'Annual review': 'Review', '12 month review': 'Review',
    'rev': 'Review', 'periodic review': 'Review', 'REVIEW': 'Review',
    'Appeal': 'Appeal', 'appeals': 'Appeal', 'Appeal - panel': 'Appeal', 'APPEAL': 'Appeal',
    'app': 'Appeal', 'appeal': 'Appeal', 'panel appeal': 'Appeal'
}

def load_and_audit_raw_data(csv_path):
    print('=' * 70)
    print('STEP 1: INGESTION AND RAW DATA QUALITY AUDIT')
    print('=' * 70)
    raw_df = pd.read_csv(csv_path, dtype=str)
    n_raw = len(raw_df)
    print(f'Loaded raw export: {n_raw:,} records across {len(raw_df.columns)} columns.')
    missing_summary = raw_df.isna().sum()
    print('\nMissing values per column:')
    for col, count in missing_summary.items():
        pct = (count / n_raw) * 100
        print(f'  - {col:15s}: {count:6,d} ({pct:5.2f}%)')
    return raw_df

def run_cleaning_pipeline(raw_df):
    print('\n' + '=' * 70)
    print('STEP 2: REPRODUCIBLE CLEANING AND AUDIT LOG GENERATION')
    print('=' * 70)
    df = raw_df.copy()
    cleaning_log = []
    
    df['clean_id'] = df['case_id'].str.upper().str.replace(r'[^A-Z0-9]', '', regex=True)
    df['client_ref_clean'] = df['client_ref'].str.strip().str.title()
    df['intake_dt'] = pd.to_datetime(df['intake_date'], format='mixed')
    df['closure_dt'] = pd.to_datetime(df['closure_date'], format='mixed')
    df['contact_count_int'] = pd.to_numeric(df['contact_count'], errors='coerce')
    df['category_clean'] = df['category'].map(CATEGORY_MAP)
    
    df_sorted = df.sort_values(['clean_id', 'contact_count_int'], ascending=[True, False])
    dedup_df = df_sorted.drop_duplicates(subset=['clean_id'], keep='first').copy()
    
    dropped_dups = df_sorted[df_sorted.duplicated(subset=['clean_id'], keep='first')]
    for idx, row in dropped_dups.iterrows():
        cleaning_log.append({
            'case_id_raw': row['case_id'],
            'clean_id': row['clean_id'],
            'action': 'DROPPED_DUPLICATE',
            'reason': 'Secondary duplicate row merged into canonical record; max contact count retained.',
            'intake_date': row['intake_date'],
            'closure_date': row['closure_date'],
            'status': row['status']
        })
        
    print(f'Deduplication: Retained {len(dedup_df):,} unique records; dropped {len(dropped_dups):,} duplicate rows.')
    
    dedup_df['duration'] = (dedup_df['closure_dt'] - dedup_df['intake_dt']).dt.days
    
    open_mask = dedup_df['status'] == 'Open'
    closed_mask = dedup_df['status'] == 'Closed'
    impossible_mask = closed_mask & (dedup_df['duration'] < 0)
    valid_closed_mask = closed_mask & (dedup_df['duration'] >= 0)
    
    impossible_df = dedup_df[impossible_mask]
    for idx, row in impossible_df.iterrows():
        reason_detail = 'Impossible date: closure precedes intake'
        if row['closure_dt'] == pd.to_datetime('2024-07-01'):
            reason_detail += ' (2024-07-01 batch administrative closure artifact)'
        cleaning_log.append({
            'case_id_raw': row['case_id'],
            'clean_id': row['clean_id'],
            'action': 'DROPPED_IMPOSSIBLE_RECORD',
            'reason': reason_detail,
            'intake_date': row['intake_date'],
            'closure_date': row['closure_date'],
            'status': row['status']
        })
        
    print(f'Validation: Dropped {len(impossible_df):,} impossible closed records (closure < intake).')
    print(f'Retained {open_mask.sum():,} open cases (right-censored) and {valid_closed_mask.sum():,} valid closed cases.')
    
    cleaning_log_df = pd.DataFrame(cleaning_log)
    cleaning_log_df.to_csv(os.path.join(OUTPUT_DIR, 'cleaning_log.csv'), index=False)
    print(f'Cleaning log exported to outputs/cleaning_log.csv ({len(cleaning_log_df):,} rows).')
    
    dedup_df.to_csv(os.path.join(OUTPUT_DIR, 'cleaned_cases_all.csv'), index=False)
    valid_closed_df = dedup_df[valid_closed_mask].copy()
    valid_closed_df.to_csv(os.path.join(OUTPUT_DIR, 'valid_closed_cases.csv'), index=False)
    
    return dedup_df, valid_closed_df, cleaning_log_df

def compute_kaplan_meier(df_sub, time_col='time', event_col='event', n_boot=500):
    times = df_sub[time_col].values
    events = df_sub[event_col].values
    unique_times = np.sort(np.unique(times))
    n_at_risk = len(times)
    survival = 1.0
    km_table = []
    
    for t in unique_times:
        d_i = np.sum((times == t) & (events == 1))
        c_i = np.sum((times == t) & (events == 0))
        if n_at_risk > 0:
            survival *= (1.0 - d_i / n_at_risk)
        km_table.append({
            'time': t,
            'n_at_risk': n_at_risk,
            'events': d_i,
            'censored': c_i,
            'survival': survival
        })
        n_at_risk -= (d_i + c_i)
        
    km_df = pd.DataFrame(km_table)
    
    def get_percentile_time(p, df_t):
        row = df_t[df_t['survival'] <= p]
        return row['time'].iloc[0] if len(row) > 0 else np.nan
        
    median_time = get_percentile_time(0.50, km_df)
    q25_time = get_percentile_time(0.75, km_df)
    q75_time = get_percentile_time(0.25, km_df)
    
    # Bootstrap 95% Confidence Interval for KM Median
    ci_low, ci_high = np.nan, np.nan
    if n_boot > 0 and len(times) > 0:
        np.random.seed(42)
        n = len(times)
        boot_meds = []
        for _ in range(n_boot):
            idx = np.random.randint(0, n, size=n)
            b_times = times[idx]
            b_events = events[idx]
            b_unique = np.sort(np.unique(b_times))
            b_n_risk = n
            b_surv = 1.0
            b_med = np.nan
            for bt in b_unique:
                bd = np.sum((b_times == bt) & (b_events == 1))
                bc = np.sum((b_times == bt) & (b_events == 0))
                if b_n_risk > 0:
                    b_surv *= (1.0 - bd / b_n_risk)
                if b_surv <= 0.5:
                    b_med = bt
                    break
                b_n_risk -= (bd + bc)
            if not np.isnan(b_med):
                boot_meds.append(b_med)
        if len(boot_meds) > 0:
            ci_low = np.percentile(boot_meds, 2.5)
            ci_high = np.percentile(boot_meds, 97.5)
            
    return km_df, median_time, q25_time, q75_time, (ci_low, ci_high)

def analyze_operational_questions(dedup_df, valid_closed_df):
    print('\n' + '=' * 70)
    print('STEP 3: RIGOROUS OPERATIONAL ANALYSIS')
    print('=' * 70)
    
    valid_closed_df['intake_year'] = valid_closed_df['intake_dt'].dt.year
    valid_closed_df['closure_year'] = valid_closed_df['closure_dt'].dt.year
    valid_closed_df['intake_ym'] = valid_closed_df['intake_dt'].dt.to_period('M')
    valid_closed_df['intake_qtr'] = valid_closed_df['intake_dt'].dt.to_period('Q')
    
    # -------------------------------------------------------------
    # Question 1: Closure Times Drift
    # -------------------------------------------------------------
    print('\n--- QUESTION 1: HAVE CASE CLOSURE TIMES INCREASED? ---')
    cohort_stats = []
    for yr in [2023, 2024, 2025]:
        sub = valid_closed_df[valid_closed_df['intake_year'] == yr]['duration']
        m = sub.mean()
        ci_low, ci_high = stats.t.interval(0.95, len(sub)-1, loc=m, scale=stats.sem(sub))
        cohort_stats.append({
            'Intake Year': yr,
            'Closed Count': len(sub),
            'Mean (days)': round(m, 2),
            'Mean 95% CI': f'[{ci_low:.2f}, {ci_high:.2f}]',
            'Median (days)': round(sub.median(), 1),
            'IQR (days)': round(np.percentile(sub, 75) - np.percentile(sub, 25), 1),
            'Std (days)': round(sub.std(), 2)
        })
    cohort_df = pd.DataFrame(cohort_stats)
    print('\nIntake Cohort Closure Times (Closed-only):')
    print(cohort_df.to_string(index=False))
    
    comp_stats = []
    for yr in [2023, 2024, 2025]:
        sub = valid_closed_df[valid_closed_df['closure_year'] == yr]['duration']
        m = sub.mean()
        ci_low, ci_high = stats.t.interval(0.95, len(sub)-1, loc=m, scale=stats.sem(sub))
        comp_stats.append({
            'Closure Year': yr,
            'Closed Count': len(sub),
            'Mean (days)': round(m, 2),
            'Mean 95% CI': f'[{ci_low:.2f}, {ci_high:.2f}]',
            'Median (days)': round(sub.median(), 1),
            'IQR (days)': round(np.percentile(sub, 75) - np.percentile(sub, 25), 1),
            'Std (days)': round(sub.std(), 2)
        })
    comp_df = pd.DataFrame(comp_stats)
    print('\nCompletion Year Closure Times:')
    print(comp_df.to_string(index=False))
    
    study_end = pd.to_datetime('2025-12-31')
    surv_df = dedup_df[~((dedup_df['status'] == 'Closed') & (dedup_df['closure_dt'] < dedup_df['intake_dt']))].copy()
    surv_df['event'] = (surv_df['status'] == 'Closed').astype(int)
    surv_df['time'] = np.where(
        surv_df['event'] == 1,
        (surv_df['closure_dt'] - surv_df['intake_dt']).dt.days,
        (study_end - surv_df['intake_dt']).dt.days
    )
    surv_df['intake_year'] = surv_df['intake_dt'].dt.year
    
    km_overall_stats = []
    km_curves = {}
    for yr in [2023, 2024, 2025]:
        sub = surv_df[surv_df['intake_year'] == yr]
        km_curve, med, q25, q75, ci_boot = compute_kaplan_meier(sub, n_boot=500)
        km_curves[yr] = km_curve
        km_overall_stats.append({
            'Intake Year': yr,
            'Total Cohort': len(sub),
            'Closed': sub['event'].sum(),
            'Right-Censored (Open)': (sub['event'] == 0).sum(),
            'KM Median (days)': med,
            'KM Median 95% CI': f'[{ci_boot[0]:.1f}, {ci_boot[1]:.1f}]',
            'KM 25th Pct': q25,
            'KM 75th Pct': q75
        })
    km_summary_df = pd.DataFrame(km_overall_stats)
    print('\nKaplan-Meier Survival Estimates (with Bootstrap 95% CIs):')
    print(km_summary_df.to_string(index=False))
    
    # -------------------------------------------------------------
    # Question 2: Operational Localization & Geographic Attribution
    # -------------------------------------------------------------
    print('\n' + '-' * 70)
    print('--- QUESTION 2: OPERATIONAL LOCALIZATION & GEOGRAPHIC ATTRIBUTION ---')
    print('Note: Analysis localizes drift to Weybridge; underlying operational mechanism is unrecorded.')
    dist_km_stats = []
    for d in ['Ash Hill', 'Calder Central', 'Northgate', 'Weybridge']:
        for yr in [2023, 2024, 2025]:
            sub = surv_df[(surv_df['district'] == d) & (surv_df['intake_year'] == yr)]
            _, med, q25, q75, ci_boot = compute_kaplan_meier(sub, n_boot=500)
            dist_km_stats.append({
                'District': d,
                'Year': yr,
                'Total Cases': len(sub),
                'Open (Censored)': (sub['event'] == 0).sum(),
                'Open Rate (%)': round(((sub['event'] == 0).sum() / len(sub)) * 100, 2),
                'KM Median (days)': med,
                'KM Median 95% CI': f'[{ci_boot[0]:.1f}, {ci_boot[1]:.1f}]',
                'KM IQR': f'[{q25:.0f}, {q75:.0f}]'
            })
    dist_km_df = pd.DataFrame(dist_km_stats)
    print('\nDistrict-by-District Survival Analysis over Time:')
    print(dist_km_df.to_string(index=False))
    
    cat_comp = []
    for cat in ['Standard', 'Complex', 'Expedited', 'Review', 'Appeal']:
        for yr in [2023, 2024, 2025]:
            wey_sub = valid_closed_df[(valid_closed_df['district'] == 'Weybridge') & (valid_closed_df['category_clean'] == cat) & (valid_closed_df['intake_year'] == yr)]
            oth_sub = valid_closed_df[(valid_closed_df['district'] != 'Weybridge') & (valid_closed_df['category_clean'] == cat) & (valid_closed_df['intake_year'] == yr)]
            cat_comp.append({
                'Category': cat,
                'Year': yr,
                'Weybridge N': len(wey_sub),
                'Weybridge Med': round(wey_sub['duration'].median(), 1) if len(wey_sub) > 0 else np.nan,
                'Other Districts N': len(oth_sub),
                'Other Districts Med': round(oth_sub['duration'].median(), 1) if len(oth_sub) > 0 else np.nan,
            })
    cat_comp_df = pd.DataFrame(cat_comp)
    
    # -------------------------------------------------------------
    # Question 3: Triage Process Evaluation
    # -------------------------------------------------------------
    print('\n' + '-' * 70)
    print('--- QUESTION 3: DID 2024 CASE TRIAGE REDUCE CLOSURE TIMES FOR HIGH-PRIORITY CASES? ---')
    post_triage = valid_closed_df[valid_closed_df['intake_dt'] >= '2024-03-01'].copy()
    prio_stats = post_triage.groupby('priority')['duration'].agg(['count', 'median', 'mean', 'std']).reset_index()
    print('\nPost-March 2024 Duration by Recorded Priority Level:')
    print(prio_stats.to_string(index=False))
    
    cohort_df.to_csv(os.path.join(OUTPUT_DIR, 'q1_intake_cohort_stats.csv'), index=False)
    comp_df.to_csv(os.path.join(OUTPUT_DIR, 'q1_completion_year_stats.csv'), index=False)
    km_summary_df.to_csv(os.path.join(OUTPUT_DIR, 'q1_km_summary_stats.csv'), index=False)
    dist_km_df.to_csv(os.path.join(OUTPUT_DIR, 'q2_district_km_stats.csv'), index=False)
    cat_comp_df.to_csv(os.path.join(OUTPUT_DIR, 'q2_category_comparison.csv'), index=False)
    prio_stats.to_csv(os.path.join(OUTPUT_DIR, 'q3_priority_stats.csv'), index=False)
    
    return {
        'cohort_df': cohort_df,
        'comp_df': comp_df,
        'km_summary_df': km_summary_df,
        'dist_km_df': dist_km_df,
        'cat_comp_df': cat_comp_df,
        'prio_stats': prio_stats,
        'km_curves': km_curves,
        'surv_df': surv_df,
        'valid_closed_df': valid_closed_df
    }

def generate_visualizations(results):
    print('\n' + '=' * 70)
    print('STEP 4: GENERATING PUBLICATION-QUALITY FIGURES')
    print('=' * 70)
    
    valid_closed_df = results['valid_closed_df']
    surv_df = results['surv_df']
    km_curves = results['km_curves']
    
    # Figure 1: District Trends
    fig, ax = plt.subplots(figsize=(10, 6))
    quarterly_dist = valid_closed_df.groupby(['intake_qtr', 'district'])['duration'].median().unstack()
    quarters_str = [str(q) for q in quarterly_dist.index]
    
    colors = {'Ash Hill': '#2ca02c', 'Calder Central': '#1f77b4', 'Northgate': '#ff7f0e', 'Weybridge': '#d62728'}
    markers = {'Ash Hill': 'o', 'Calder Central': 's', 'Northgate': '^', 'Weybridge': 'D'}
    
    for dist in quarterly_dist.columns:
        ax.plot(quarters_str, quarterly_dist[dist], label=dist, color=colors[dist],
                marker=markers[dist], linewidth=2.5 if dist == 'Weybridge' else 1.8,
                markersize=7 if dist == 'Weybridge' else 5)
        
    ax.axvline(x='2024Q3', color='black', linestyle='--', alpha=0.7, label='August 2024 Shock')
    ax.annotate('Weybridge Operational Shock\n(Median jumps from 34d to 77d+)',
                xy=('2024Q3', 67.5), xytext=('2024Q1', 75),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8),
                fontsize=10, fontweight='bold', bbox=dict(boxstyle='round,pad=0.5', facecolor='#fee', edgecolor='#d62728'))
    
    ax.set_title('Quarterly Median Case Closure Duration by District (2023 - 2025)', fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel('Intake Quarter', fontsize=11, fontweight='bold')
    ax.set_ylabel('Median Closure Time (Days)', fontsize=11, fontweight='bold')
    ax.legend(title='District', frameon=True, facecolor='white', loc='upper left')
    ax.grid(True, linestyle=':', alpha=0.6)
    plt.xticks(rotation=45)
    plt.tight_layout()
    fig_path1 = os.path.join(FIGURES_DIR, 'district_quarterly_drift.png')
    plt.savefig(fig_path1)
    plt.close()
    print(f'Saved: {fig_path1}')
    
    # Figure 2: Kaplan-Meier Survival Curves
    fig, ax = plt.subplots(figsize=(10, 6))
    km_colors = {2023: '#1f77b4', 2024: '#ff7f0e', 2025: '#d62728'}
    
    for yr in [2023, 2024, 2025]:
        curve = km_curves[yr]
        med_val = results['km_summary_df'].loc[results['km_summary_df']['Intake Year']==yr, 'KM Median (days)'].values[0]
        med_ci = results['km_summary_df'].loc[results['km_summary_df']['Intake Year']==yr, 'KM Median 95% CI'].values[0]
        ax.step(curve['time'], curve['survival'] * 100, where='post',
                label=f'Intake {yr} (KM Med = {med_val:.0f}d, 95% CI: {med_ci})',
                color=km_colors[yr], linewidth=2.2)
        
    ax.axhline(y=50, color='gray', linestyle=':', label='50% Closure Threshold (Median)')
    ax.set_xlim(0, 180)
    ax.set_ylim(0, 105)
    ax.set_title('Kaplan-Meier Case Survival Curves by Intake Cohort (Adjusted for Right Censoring)', fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel('Days from Case Intake', fontsize=11, fontweight='bold')
    ax.set_ylabel('Percentage of Cases Remaining Open (%)', fontsize=11, fontweight='bold')
    ax.legend(frameon=True, facecolor='white', loc='upper right')
    ax.grid(True, linestyle=':', alpha=0.6)
    plt.tight_layout()
    fig_path2 = os.path.join(FIGURES_DIR, 'kaplan_meier_survival_curves.png')
    plt.savefig(fig_path2)
    plt.close()
    print(f'Saved: {fig_path2}')
    
    # Figure 3: Priority Timeline & Duration
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5))
    
    prio_monthly = surv_df.groupby([surv_df['intake_dt'].dt.to_period('M'), surv_df['priority'].fillna('Missing')]).size().unstack(fill_value=0)
    prio_monthly.plot(kind='bar', stacked=True, ax=ax1, color={'Missing': '#999999', 'High': '#d62728', 'Medium': '#ff7f0e', 'Low': '#2ca02c'})
    ax1.set_title('Priority Field Recording Over Time (Jan 2023 - Dec 2025)', fontsize=11, fontweight='bold')
    ax1.set_xlabel('Intake Month', fontsize=10)
    ax1.set_ylabel('Case Count', fontsize=10)
    ax1.legend(title='Recorded Priority')
    ticks = range(0, len(prio_monthly), 3)
    ax1.set_xticks(ticks)
    ax1.set_xticklabels([str(prio_monthly.index[i]) for i in ticks], rotation=45)
    
    post_triage = valid_closed_df[valid_closed_df['intake_dt'] >= '2024-03-01'].copy()
    prio_cat = post_triage.groupby(['category_clean', 'priority'])['duration'].median().unstack()
    prio_cat.plot(kind='bar', ax=ax2, color={'High': '#d62728', 'Medium': '#ff7f0e', 'Low': '#2ca02c'})
    ax2.set_title('Median Duration by Category & Priority (Post-March 2024)', fontsize=11, fontweight='bold')
    ax2.set_xlabel('Standardized Case Category', fontsize=10)
    ax2.set_ylabel('Median Closure Time (Days)', fontsize=10)
    ax2.legend(title='Priority')
    plt.xticks(rotation=0)
    
    plt.tight_layout()
    fig_path3 = os.path.join(FIGURES_DIR, 'priority_triage_analysis.png')
    plt.savefig(fig_path3)
    plt.close()
    print(f'Saved: {fig_path3}')
    
    # Figure 4: Category Drift Comparison
    fig, ax = plt.subplots(figsize=(10, 5.5))
    cat_comp_pivot = results['cat_comp_df'].pivot(index='Category', columns=['Year'], values=['Weybridge Med', 'Other Districts Med'])
    
    bar_width = 0.12
    x = np.arange(len(cat_comp_pivot))
    
    years = [2023, 2024, 2025]
    for i, yr in enumerate(years):
        ax.bar(x + i*bar_width, cat_comp_pivot[('Other Districts Med', yr)], width=bar_width,
               label=f'Other Districts {yr}', alpha=0.8, color=['#a6cee3', '#1f78b4', '#08306b'][i])
    for i, yr in enumerate(years):
        ax.bar(x + (i+3.5)*bar_width, cat_comp_pivot[('Weybridge Med', yr)], width=bar_width,
               label=f'Weybridge {yr}', alpha=0.85, color=['#fb9a99', '#e31a1c', '#67000d'][i])
        
    ax.set_xticks(x + 3 * bar_width)
    ax.set_xticklabels(cat_comp_pivot.index, fontweight='bold')
    ax.set_title('Median Closure Duration: Other Districts vs Weybridge by Category (2023 - 2025)', fontsize=12, fontweight='bold', pad=15)
    ax.set_ylabel('Median Days to Close', fontsize=11, fontweight='bold')
    ax.legend(bbox_to_anchor=(1.02, 1), loc='upper left', frameon=True)
    ax.grid(True, linestyle=':', alpha=0.6)
    plt.tight_layout()
    fig_path4 = os.path.join(FIGURES_DIR, 'category_district_drift_comparison.png')
    plt.savefig(fig_path4)
    plt.close()
    print(f'Saved: {fig_path4}')

def main():
    raw_df = load_and_audit_raw_data(RAW_CSV)
    dedup_df, valid_closed_df, cleaning_log_df = run_cleaning_pipeline(raw_df)
    results = analyze_operational_questions(dedup_df, valid_closed_df)
    generate_visualizations(results)
    print('\n' + '=' * 70)
    print('PIPELINE EXECUTION COMPLETE - ALL ARTIFACTS GENERATED SUCCESSFULLY')
    print('=' * 70)

if __name__ == '__main__':
    main()
