﻿# Problem 2 — Dirty Data, Real Decisions

**Brite Spark 2026 · Data / Analytics Track**  
**Repository**: Case Management System Quality Audit & Operational Investigation (2023–2025)

---

## 📌 Project Overview

This repository contains the complete diagnostic data quality assessment, deterministic cleaning pipeline, Kaplan-Meier survival modeling (with 95% bootstrap confidence intervals), and operational investigation answering three critical questions posed by program leadership regarding case closure time drift.

### Core Operational Takeaways

1. **Question 1 (Closure Drift)**: **Yes**, case closure times increased across the program. Adjusting for right-censored open cases via Kaplan-Meier survival analysis, system median closure time lengthened from **34.0 days (95% CI: [33.0, 35.0]) in 2023** to **43.0 days (95% CI: [42.0, 45.0]) in 2025** (+9.0 days / +26.5%).
2. **Question 2 (Operational Localization & Geographic Attribution)**: The slowdown is **100% concentrated in Weybridge District** beginning abruptly in **August 2024 (Q3 2024)**, where median closure durations surged from 36.0 days to **80.0 days [75.5, 85.0]** across every single case type. In the other three districts (Ash Hill, Calder Central, Northgate), closure times remained completely flat (~30–37 days). *(Note: The underlying local physical mechanism is unrecorded in this export).*
3. **Question 3 (2024 Triage Efficacy)**: **GENUINELY CANNOT BE ANSWERED FROM THIS DATA**. The `priority` field was 100% unrecorded (5,856 missing rows) from Jan 2023 through Feb 2024, providing zero pre-intervention baseline. Furthermore, post-March 2024 priority explains zero variance in duration once controlling for case category.

---

## 📂 Repository Structure

```
├── data pack/
│   ├── case-export-2023-2025.csv       # Raw CMS export (15,100 records)
│   ├── README.md                       # Original problem brief
│   └── questions.md                    # Operational questions from Director
├── figures/                            # Publication-quality charts (300 DPI)
│   ├── district_quarterly_drift.png    # Quarterly trend showing Weybridge shock
│   ├── kaplan_meier_survival_curves.png# Survival curves adjusting for censoring
│   ├── priority_triage_analysis.png    # Missingness timeline & priority breakdown
│   └── category_district_drift_comparison.png # Weybridge vs Other Districts by Category
├── outputs/                            # Exported datasets and statistical tables
│   ├── cleaned_cases_all.csv           # Master unique cases (14,200 records)
│   ├── valid_closed_cases.csv          # Valid closed records (12,903 records)
│   ├── cleaning_log.csv                # Complete audit log (1,446 dropped/merged rows)
│   ├── q1_intake_cohort_stats.csv      # Q1 cohort statistics
│   ├── q1_completion_year_stats.csv    # Q1 completion year statistics
│   ├── q1_km_summary_stats.csv         # Q1 Kaplan-Meier summary metrics (with CIs)
│   ├── q2_district_km_stats.csv        # Q2 district-level survival metrics (with CIs)
│   ├── q2_category_comparison.csv      # Q2 category breakdown by district
│   └── q3_priority_stats.csv           # Q3 post-2024 priority duration metrics
├── pipeline.py                         # Master reproducible Python pipeline
├── generate_pdf_report.py              # Script to build executive PDF report
├── Problem_2_Dirty_Data_Real_Decisions_Executive_Report.pdf # Executive PDF Report
├── analysis_notebook.ipynb             # Interactive Jupyter Notebook analysis
├── DATA_QUALITY_ASSESSMENT.md          # Comprehensive Data Quality Assessment report
├── OPERATIONAL_ANSWERS.md              # Detailed answers to Questions 1, 2, and 3
├── CLEANING_LOG.md                     # Documented cleaning rules and audit log
├── DECISIONS.md                        # Analytical judgements and core assumptions
├── AI-USAGE.md                         # AI collaboration disclosure
└── README.md                           # This execution guide
```

---

## 🚀 Quick Start: Running from a Clean Clone

### 1. Prerequisites
- Python 3.9+
- Standard data science libraries:
```bash
pip install pandas numpy scipy matplotlib nbformat jupyter reportlab
```

### 2. Run the Full Analysis Pipeline
Execute the automated end-to-end pipeline from the repository root:
```bash
python pipeline.py
```

### 3. Generate Executive PDF Report
```bash
python generate_pdf_report.py
```

### 4. Open the Interactive Jupyter Notebook
```bash
jupyter notebook analysis_notebook.ipynb
```

---
