﻿# Data Cleaning Log & Transformation Audit

**Dataset**: `case-export-2023-2025.csv`  
**Execution Timestamp**: 2026-08-23  
**Pipeline Script**: `pipeline.py`  
**Cleaning Log Export**: `outputs/cleaning_log.csv` (1,446 detailed audit entries)

---

## 1. Summary of Cleaning Operations

```
Raw Export Ingested:             15,100 rows
---------------------------------------------------------
1. Secondary Duplicates Dropped: -900 rows   (Merged into canonical records)
2. Unique Cases Retained:        14,200 cases  (100% unique canonical ID)
   - Valid Closed Cases:         12,903 cases  (Used for closed-case statistics)
   - Valid Open Cases:              751 cases  (Used for Kaplan-Meier survival modeling)
   - Impossible Closed Dropped:   -546 cases  (Excluded from duration calculations)
---------------------------------------------------------
Total Dropped / Excluded:        1,446 rows
Cleaned Analysis Baseline:       13,654 cases  (12,903 valid closed + 751 valid open)
```

---

## 2. Detailed Transformation & Drop Rules

### Operation 1: Canonical Case Identification & Deduplication
- **Affected Rows in Raw Data**: 1,800 rows (900 duplicate pairs).
- **Transformation Applied**:
  1. `case_id` was stripped of non-alphanumeric characters and capitalized: `norm_id = re.sub(r'[^A-Z0-9]', '', id).upper()`.
  2. `client_ref` was standardized to stripped Title Case (`client_ref.strip().title()`).
  3. Records were sorted by `norm_id` and `contact_count` descending. The record with the maximum contact count was preserved as canonical.
- **Action Taken**: **900 secondary duplicate rows were dropped** and logged in `outputs/cleaning_log.csv` under action `DROPPED_DUPLICATE`.
- **Analytical Rationale**: Retains 100% of distinct physical clients while merging split snapshot exports and preserving maximum contact logging fidelity.

---

### Operation 2: Standardization of Uncontrolled Category Text
- **Affected Rows in Raw Data**: 15,100 rows (across 40 unique string variations).
- **Transformation Applied**:
  Deterministic mapping to 5 standard operational case categories:
  - **Standard (7,338 cases)**: `Standard`, `routine`, `standard - no issues`, `normal`, `Standard case`, `std`, `Std.`, `standard`, `STANDARD`.
  - **Complex (3,176 cases)**: `Complex`, `complex case`, `COMPLEX`, `multi-agency`, `complicated`, `cmplx`, `Complex - multi agency`, `Complex (referred)`, `complex`.
  - **Expedited (1,742 cases)**: `Expedited`, `exp`, `rush`, `expedited`, `fast track`, `Expedited - urgent`, `URGENT`, `expedite`.
  - **Review (1,578 cases)**: `Review`, `review`, `Annual review`, `12 month review`, `rev`, `periodic review`, `REVIEW`.
  - **Appeal (1,266 cases)**: `Appeal`, `appeals`, `Appeal - panel`, `APPEAL`, `app`, `appeal`, `panel appeal`.
- **Action Taken**: 100% of records mapped; 0 rows dropped.
- **Analytical Rationale**: Recovers complete categorical vocabulary without discarding free-text records entered by caseworkers.

---

### Operation 3: Date Parsing & Locale Standardization
- **Affected Rows in Raw Data**: 15,100 intake dates and 14,304 non-null closure dates.
- **Transformation Applied**:
  - Parsed mixed formats: ISO 8601 (`YYYY-MM-DD`), US Slash (`MM/DD/YYYY`), and Verbose (`Month D, YYYY`) into unified `datetime64[ns]`.
  - Verified US date format convention across all 8,640 slash dates (5,168 dates with day $>12$ in second component; 0 in first component).
- **Action Taken**: Converted to standard datetime; 0 unparseable dates.
- **Analytical Rationale**: Standardizes temporal math across multi-format exports.

---

### Operation 4: Impossible Date Contradictions (Closure < Intake)
- **Affected Records in Deduplicated Data**: 546 closed cases.
- **Investigation & Classification**:
  1. **2024-07-01 Mass Closure Batch Artifact (296 cases)**:
     - 616 deduplicated cases share the closure date `2024-07-01`.
     - In 296 cases, the case was opened *after* July 1, 2024 (e.g., intake `2024-11-27` with closure `2024-07-01`), producing negative durations up to -510 days.
     - Root Cause: Administrative batch update script overwrote open case records with a static date.
  2. **Corrupted Historical Timestamps (250 cases)**:
     - Cases opened in 2023/2024/2025 with recorded closure dates in 2021/2022/2023 (e.g., intake March 2024, closure September 2023).
- **Action Taken**: **546 impossible closed records dropped** from closure velocity calculations and logged in `outputs/cleaning_log.csv` under action `DROPPED_IMPOSSIBLE_RECORD`.
- **Analytical Rationale**: Retaining negative closure durations corrupts statistical means, standard deviations, and survival estimates.

---

### Operation 5: Right-Censoring Partition (Open Cases)
- **Affected Records in Deduplicated Data**: 751 open cases (`status == 'Open'`, `closure_date == NaN`).
- **Action Taken**:
  - Retained in master dataset (`cleaned_cases_all.csv`).
  - Included as right-censored observations in Kaplan-Meier survival analysis ($\text{event} = 0$, observation time $= \text{study\_end} - \text{intake\_dt}$).
  - Excluded from empirical closed-case arithmetic duration means.
- **Analytical Rationale**: Prevents survivorship bias in 2025 metrics while acknowledging open status.

---

## 3. Cleaning Audit Trail Summary Table

| Step | Rule Applied | Rows Before | Rows Transformed | Rows Dropped | Rows After | Log Reference |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **0** | Raw Export Ingestion | 15,100 | - | - | 15,100 | `case-export-2023-2025.csv` |
| **1** | Case ID Normalization & Deduplication | 15,100 | 1,800 | **900** | 14,200 | `cleaning_log.csv` (`DROPPED_DUPLICATE`) |
| **2** | Category Free-Text Reconciliation | 14,200 | 4,828 | 0 | 14,200 | `pipeline.py:CATEGORY_MAP` |
| **3** | Multi-Format Date Parsing | 14,200 | 6,347 | 0 | 14,200 | `pipeline.py:parse_dates` |
| **4** | Impossible Date Removal (Closure < Intake) | 14,200 | 546 | **546** | 13,654 | `cleaning_log.csv` (`DROPPED_IMPOSSIBLE_RECORD`) |
| **5** | Right-Censoring Partition (Open vs Closed) | 13,654 | 751 (Open) | 0 | 13,654 | `valid_closed_cases.csv` (12,903) & `cleaned_cases_all.csv` (13,654) |

---
