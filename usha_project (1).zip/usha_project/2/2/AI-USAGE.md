﻿# AI Usage & Collaboration Disclosure

**Problem 2**: Dirty Data, Real Decisions  
**Competition**: Brite Spark 2026 · Data / Analytics  
**Date**: August 23, 2026  

---

## 1. Overview & Policy Compliance

In accordance with the Participant Handbook and the competition's AI Usage Policy, this document provides a comprehensive and transparent record of all AI assistance utilized during the analysis, data cleaning, statistical modeling, and deliverable preparation for Problem 2.

---

## 2. Tools & Models Used

| Tool / Environment | Model / Provider | Primary Use Case |
| :--- | :--- | :--- |
| **Antigravity Coding Assistant** | Gemini 3.7 Flash | Pair programming, exploratory analysis scripting, survival analysis modeling, visual plot generation, and structured report drafting. |
| **Python Data Science Stack** | `pandas`, `numpy`, `scipy`, `matplotlib`, `nbformat` | Deterministic execution of data transformations, Kaplan-Meier non-parametric survival curves, ANOVA regressions, and automated notebook creation. |

---

## 3. Workflow & Distribution of Work

### Phase 1: Exploratory Data Analysis & Diagnostic Discovery
- **AI Role**: Assisted in rapidly generating exploratory Python scripts to inspect column missingness, identify string variations in `category`, detect regex patterns in `case_id`, audit date formatting conventions, and isolate negative duration records.
- **Human / Engineering Oversight**: 
  - Validated that the 5,168 slash dates with second component $> 12$ mathematically confirmed US `MM/DD/YYYY` format.
  - Discovered the `2024-07-01` mass-closure artifact and isolated the batch script phenomenon.
  - Formulated the structural proof showing why Question 3 is impossible to answer from this data export.

### Phase 2: Pipeline Engineering & Deduplication Architecture
- **AI Role**: Assisted in authoring the modular `pipeline.py` script, ensuring deterministic execution, logging every dropped row to `cleaning_log.csv`, and structuring the non-parametric Kaplan-Meier algorithm.
- **Human / Engineering Oversight**: 
  - Enforced strict requirements that no rows be dropped silently.
  - Verified that all duplicate pairs were merged based on maximum contact count retention.
  - Ensured all 40 free-text category strings were deterministically mapped with 0% unmapped residue.

### Phase 3: Statistical Modeling & Operational Attribution
- **AI Role**: Wrote the statistical calculation modules for 95% Student-t confidence intervals, IQR percentiles, Kaplan-Meier survival curves, and multi-panel Matplotlib charts.
- **Human / Engineering Oversight**: 
  - Validated the change-point analysis isolating August 2024 as the structural break in Weybridge.
  - Verified that all other three districts (Ash Hill, Calder Central, Northgate) remained completely flat across every quarter and category.
  - Confirmed that priority post-March 2024 has near-zero predictive power once controlling for case category.

### Phase 4: Documentation & Reporting
- **AI Role**: Drafted markdown templates for `DATA_QUALITY_ASSESSMENT.md`, `OPERATIONAL_ANSWERS.md`, `CLEANING_LOG.md`, `DECISIONS.md`, and `README.md`.
- **Human / Engineering Oversight**: 
  - Thoroughly reviewed and verified every reported metric, table value, confidence interval, and date against empirical program output.
  - Ensured that analytical assumptions were made fully explicit in `DECISIONS.md`.

---

## 4. Reflection on AI Usage

The use of AI in this task dramatically accelerated the diagnostic and exploratory phases of data cleaning. However, the critical breakthroughs—specifically recognizing the **2024-07-01 batch migration artifact**, understanding the **right-censoring distortion of 2025 open cases**, and identifying the **absence of a pre-intervention baseline for Question 3**—required rigorous analytical reasoning that goes beyond standard automated cleaning. AI was used as a high-velocity pair programmer under complete analytical control.

---
