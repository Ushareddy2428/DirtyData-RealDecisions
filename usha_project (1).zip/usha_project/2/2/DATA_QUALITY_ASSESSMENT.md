﻿# Data Quality Assessment: Case Management System Export (2023–2025)

**Author**: Analytics & Data Quality Engineering Team  
**Dataset**: `case-export-2023-2025.csv` (15,100 raw records, 10 columns)  
**Date Range Analyzed**: January 1, 2023 – December 31, 2025  
**Coverage**: 4 District Offices (Ash Hill, Calder Central, Northgate, Weybridge)

---

## 1. Executive Summary

This Data Quality Assessment provides a comprehensive diagnostic audit of the case export extracted from the legacy Case Management System. The export reflects years of system unmaintenance, uncoordinated software migrations, evolving schema rules, and uncontrolled manual data entry across four regional offices.

### Core Audit Findings

| Quality Dimension | Raw State | Audit Finding | Analytical Impact & Remedy |
| :--- | :--- | :--- | :--- |
| **Identifier Integrity** | 15,100 raw rows | **1,800 duplicate rows (900 unique case pairs)** differing by character case (`cc-` vs `CC-`), punctuation, whitespace, and contact counts (+/-1). | Canonical normalization collapses records to **14,200 unique cases**. Retained highest contact count per canonical ID. |
| **Date Serialization** | 3 competing formats | Mixed ISO 8601 (`YYYY-MM-DD`, 55.8%), US slash (`MM/DD/YYYY`, 29.4%), and verbose string (`Month D, YYYY`, 14.8%). | All slash dates mathematically confirmed as US `MM/DD/YYYY` format (5,168 second components > 12; zero first components > 12). |
| **Temporal Contradictions** | 14,304 closed cases | **573 records with impossible dates** (closure date precedes intake date). | **311 records** are tied to a single mass-closure batch artifact on **2024-07-01**; 262 are corrupted historical entries. Excluded 546 impossible closed records from duration stats. |
| **Categorical Standardization** | 40 distinct strings | Roughly 34% of the category column consists of free-text synonyms and abbreviations for 5 underlying operational case types. | **100% deterministic mapping** achieved into 5 standard categories (`Standard`, `Complex`, `Expedited`, `Review`, `Appeal`) with zero unmapped residue. |
| **Systematic Attribute Missingness** | 5,856 missing priority values (38.8%) | Missingness is **100% structurally temporal**: exactly 0% recorded from Jan 2023 to Feb 2024; 100% recorded from March 2024 onward. | Makes pre/post comparative evaluation of the 2024 triage rollout for high-priority cases **statistically impossible**. |
| **Right-Censoring / Survivorship** | 796 raw (751 deduplicated) open cases | **100% of open cases originate in 2025**. | Naive closed-case averages underestimate true 2025 closure times. Corrected via **Kaplan-Meier survival estimation**. |

---

## 2. Deep-Dive Quality Dimensions

### Dimension 1: Identifier Integrity and Deduplication

A total of **1,800 records** in the export represent duplicate representations of **900 unique underlying cases**. The fragmentation stems from three systemic mechanisms:
1. **Identifier Formatting Inconsistency**: Identifiers appear with varying letter casing (`CC-2023-10091` vs `cc-2023-10091`), dash placement, and space insertion (`CC 2023 10334` vs `CC-2023-10334`).
2. **Client Name Casing**: In 268 duplicate pairs, the `client_ref` field alternates between `UPPERCASE` and `Title Case` (e.g., `BETTY DELGADO` vs `Betty Delgado`).
3. **Contact Count Divergence**: In 419 duplicate pairs, the `contact_count` field differs by exactly $\pm 1$ (e.g., 3 vs 4 contacts). This indicates asynchronous snapshot extraction across two un-synchronized database replicas.

```
+-----------------------------------------------------------------------------------+
| Duplicate Example: Case CC-2023-10091                                             |
+-----------------------------------------------------------------------------------+
| Row 12138: CC-2023-10091 | Emily Bennett | Ash Hill | 2023-01-01 | Closed | 4 contacts |
| Row 9572:  cc-2023-10091 | Emily Bennett | Ash Hill | 01/01/2023 | Closed | 3 contacts |
+-----------------------------------------------------------------------------------+
| Resolution: Merged to CC202310091, canonical dates parsed, contact_count = 4.     |
+-----------------------------------------------------------------------------------+
```

**Remediation Rule**:
Each `case_id` was stripped of non-alphanumeric characters and converted to uppercase (`re.sub(r'[^A-Z0-9]', '', id).upper()`). Duplicates were sorted by contact count descending, preserving the most complete record and reducing the dataset from 15,100 to **14,200 unique cases**.

---

### Dimension 2: Temporal Field Integrity and Impossible Values

#### Mixed Date Formats
The system exported dates in three distinct string formats across both `intake_date` and `closure_date`:
- `YYYY-MM-DD` (ISO 8601): 8,427 intake dates (55.8%), 7,994 closure dates (55.9%)
- `M/D/YYYY` (Slash-delimited): 4,433 intake dates (29.4%), 4,207 closure dates (29.4%)
- `Month D, YYYY` (Verbose text): 2,240 intake dates (14.8%), 2,103 closure dates (14.7%)

**Validation Proof for Ambiguous Slash Dates**:
To ensure no ambiguous dates (e.g., `03/04/2024`) were parsed under the wrong locale (US `MM/DD` vs UK `DD/MM`), all 8,640 slash dates were audited:
- Number of dates where Part 1 $> 12$ (forcing `DD/MM/YYYY`): **0**
- Number of dates where Part 2 $> 12$ (forcing `MM/DD/YYYY`): **5,168**
- **Conclusion**: The source database strictly serialized all slash dates in US **`MM/DD/YYYY`** format.

#### Physically Impossible Records & The 2024-07-01 Batch Artifact
Across deduplicated closed cases, **546 records** contain closure dates that precede their intake date ($\text{duration} < 0$).
An exhaustive investigation revealed two root causes:
1. **The 2024-07-01 Batch Closure Script Artifact**:
   - A single timestamp—`2024-07-01`—is assigned to **616 deduplicated cases**.
   - Of these, **296 cases were opened after July 1, 2024** (e.g., intake on `2024-11-27` with closure on `2024-07-01`).
   - This proves that an automated administrative batch update script executed on or around July 1, 2024, forcibly overwrote closure dates with a static default value.
2. **Corrupted Historical Timestamps**:
   - **250 records** contain closure years that precede intake years by months or years (e.g., intake in March 2024, closure recorded in September 2023; intake in January 2023, closure recorded in September 2022).

**Remediation Rule**:
All 546 impossible closed records were logged in `cleaning_log.csv` and excluded from operational duration calculations to avoid distorting velocity and survival metrics.

---

### Dimension 3: Categorical Free-Text Normalization

The raw `category` field contained **40 unique textual strings**. However, clustering and domain reconciliation reveal that every single entry represents one of **5 standard operational categories**:

| Standard Category | Raw Variations in Export | Canonical Count | Pct (%) |
| :--- | :--- | :--- | :--- |
| **Standard** | `Standard`, `routine`, `standard - no issues`, `normal`, `Standard case`, `std`, `Std.`, `standard`, `STANDARD` | 7,338 | 48.6% |
| **Complex** | `Complex`, `complex case`, `COMPLEX`, `multi-agency`, `complicated`, `cmplx`, `Complex - multi agency`, `Complex (referred)`, `complex` | 3,176 | 21.0% |
| **Expedited** | `Expedited`, `exp`, `rush`, `expedited`, `fast track`, `Expedited - urgent`, `URGENT`, `expedite` | 1,742 | 11.5% |
| **Review** | `Review`, `review`, `Annual review`, `12 month review`, `rev`, `periodic review`, `REVIEW` | 1,578 | 10.5% |
| **Appeal** | `Appeal`, `appeals`, `Appeal - panel`, `APPEAL`, `app`, `appeal`, `panel appeal` | 1,266 | 8.4% |
| **Total** | **40 Unique String Variations** | **15,100** | **100.0%** |

**Remediation Rule**:
A 1:1 deterministic mapping was established. Zero cases were unmapped or discarded.

---

### Dimension 4: Systematic Attribute Missingness (The Priority Field)

The `priority` column is missing in **5,856 rows (38.8%)**. Rather than random missingness (MCAR), this missingness is **strictly structural and temporal**:
- **Jan 1, 2023 – Feb 29, 2024 (14 months)**: Exactly **0% recorded** (5,856 out of 5,856 cases are `NaN`).
- **March 1, 2024 – Dec 31, 2025 (22 months)**: Exactly **100% recorded** (9,244 out of 9,244 cases populated with `High`, `Medium`, or `Low`).

```
Priority Field Population Timeline:
2023-01 to 2024-02: [==================== 100% MISSING ====================] (0 / 5,856 populated)
2024-03 to 2025-12: [#################### 100% POPULATED ##################] (9,244 / 9,244 populated)
```

**Analytical Consequence**:
The absence of priority data throughout 2023 and early 2024 means there is **zero historical baseline** for high-priority cases. It is mathematically impossible to evaluate whether the 2024 triage process reduced high-priority closure times compared to earlier periods.

---

### Dimension 5: Censoring and Survivorship Bias

Across the deduplicated dataset of 14,200 records:
- **13,449 cases are marked Closed** (of which 12,903 are valid non-negative durations).
- **751 cases are marked Open** (closure date is null).

**Key Observation**:
**100% of the 751 open cases were opened in 2025**. Zero open cases remain from 2023 or 2024.
- Because complex and slow-moving cases opened in late 2025 had not reached closure by December 31, 2025, evaluating only "closed cases" introduces severe **right-censoring bias** (survivorship bias).
- Naive closed-only median duration for 2025 is **38.0 days**, but the true right-censoring-adjusted **Kaplan-Meier median survival time is 43.0 days**.

---

## 3. Data Quality Summary & Operational Readiness

| Cleaned Partition | Row Count | % of Raw Export | Primary Analytical Role |
| :--- | :--- | :--- | :--- |
| **Raw Input Export** | 15,100 | 100.0% | Ingestion baseline |
| **Dropped Duplicate Rows** | -900 | -6.0% | Merged into canonical cases |
| **Unique Case Master** | 14,200 | 94.0% | Total unique operational caseload |
| **Valid Open Cases (Right-Censored)** | 751 | 5.0% | Retained for survival analysis (Kaplan-Meier) |
| **Dropped Impossible Closed Cases** | -546 | -3.6% | Excluded due to impossible/corrupted dates |
| **Valid Closed Cases** | 12,903 | 85.5% | Primary cohort for empirical closure duration metrics |

---
