﻿# Analytical Decisions & Assumptions Log

**Problem 2**: Dirty Data, Real Decisions  
**Author**: Analytics & Data Quality Engineering Team  
**Focus**: Analytical Judgements, Semantic Interpretations, and Core Assumptions  

---

## 1. Overview & Purpose

In legacy and decaying databases, cleaning data is not merely a technical exercise in string parsing; **every transformation embodies an analytical assumption about what a record meant in the real world**. 

This document records the foundational analytical assumptions and judgements underpinning our findings, making them explicit and transparent to program leadership and reviewing auditors.

---

## 2. Inventory of Analytical Decisions & Assumptions

### Decision 1: Case Identity and Duplicate Interpretation
- **The Observation**: 1,800 rows share normalized case references in pairs of two, differing in punctuation, casing, client name formatting, and contact counts ($\pm 1$).
- **The Assumption**: We assumed that records sharing the same alphanumeric root (e.g., `CC-2023-10091` and `cc-2023-10091`) represent **duplicate database rows of the same physical client case**, rather than distinct, consecutive cases opened by the same individual.
- **The Judgement on Divergent Values**: Where contact counts differed by $\pm 1$, we assumed the higher count represents the later, more complete snapshot of case activity, merging the two into a single canonical record with the maximum contact count.
- **Risk if Assumption is False**: If these were distinct repeat filings, our deduplication would slightly undercount total case volume by 6.0% (900 cases out of 15,100). However, case duration distributions would remain completely unchanged because durations are identical between pairs.

---

### Decision 2: Date Locale and Format Interpretation
- **The Observation**: Dates appeared in mixed formats, including slash-delimited dates like `03/04/2024`.
- **The Assumption**: We assumed all slash-delimited dates follow the **US `MM/DD/YYYY` convention**.
- **Evidence Supporting the Judgement**: Out of 8,640 slash dates in the export, exactly **5,168 records had a second component $> 12$** (e.g., `07/23/2024`, which is impossible in `DD/MM/YYYY`), while **zero records had a first component $> 12$**.
- **Risk if Assumption is False**: None. The mathematical probability of a mixed UK/US locale in this column is zero given the strict upper-bound constraint of component 1 $\le 12$.

---

### Decision 3: Treatment of Impossible Dates & The 2024-07-01 Batch Artifact
- **The Observation**: 546 closed cases possess closure dates that precede their intake dates ($\text{duration} < 0$), with 296 cases concentrated on the single closure timestamp `2024-07-01`.
- **The Assumption**: We assumed that closure dates preceding intake dates are **corrupted system artifacts** (e.g., automated batch script execution, default database migration fallback dates) rather than retroactive pre-filings or intentional operational shortcuts.
- **The Judgement**: Rather than attempting to "impute" or "swap" intake and closure dates, we strictly **dropped these 546 records from closure duration calculations** while logging every single instance in the cleaning log.
- **Risk if Assumption is False**: If `2024-07-01` was a legitimate closure date for cases opened in late 2024, it would imply time travel. Dropping them safely eliminates severe negative-duration distortion.

---

### Decision 4: Categorical Semantic Mapping
- **The Observation**: The `category` column contained 40 unique text strings (e.g., `routine`, `standard - no issues`, `std`, `cmplx`, `rush`, `appeals`).
- **The Assumption**: We assumed these 40 strings represent **uncontrolled caseworker synonyms for 5 underlying operational workflows**: `Standard`, `Complex`, `Expedited`, `Review`, and `Appeal`.
- **The Judgement**: We mapped each variation deterministically to its root category (e.g., `rush` $\rightarrow$ `Expedited`; `multi-agency` $\rightarrow$ `Complex`). Zero records were discarded as unclassifiable.
- **Risk if Assumption is False**: If `multi-agency` was intended to be an independent case category with distinct operational staffing from `Complex`, grouping them might obscure a sub-tier dynamic. However, cross-checking median durations confirmed that `multi-agency` (74d) matched `Complex` (73d) perfectly.

---

### Decision 5: Non-Informative Right Censoring of Open Cases
- **The Observation**: 751 deduplicated cases remained `Open` at the end of the observation window (December 31, 2025). All 751 cases originated in 2025.
- **The Assumption**: We assumed that open status at the end of 2025 is an artifact of **study cutoff (right censoring)** rather than cases being abandoned, lost, or permanently unresolved.
- **The Judgement**: We employed **Kaplan-Meier survival estimation** with 95% bootstrap confidence intervals to evaluate intake cohort closure velocity. This provides an unbiased median closure time of **43.0 days [42.0, 45.0] for 2025**, compared to the naive closed-only median of **38.0 days [37.0, 39.0]**.
- **Risk if Assumption is False**: If open cases in 2025 represent "dead/abandoned" files that will never close, Kaplan-Meier slightly overestimates duration; if they are complex backlogs that will take 150+ days, naive closed-only averages drastically underestimate duration. Kaplan-Meier is the standard scientific middle ground.

---

### Decision 6: Priority Missingness & The Impossibility of Question 3
- **The Observation**: The `priority` field is 100% missing from January 1, 2023 through February 29, 2024, and 100% populated thereafter.
- **The Critical Analytical Judgement**: **We refused to fabricate a synthetic baseline for 2023 high-priority cases.**
- **The Rationale**: An analyst could have made a naive assumption (e.g., "assume all Expedited cases in 2023 were High Priority" or "backfill 2023 priority based on caseworker"). We explicitly rejected this because:
  1. Priority was shown to be uncorrelated with duration within categories post-2024.
  2. Synthesizing a baseline creates the illusion of certainty where the data possesses structural absence.
- **Conclusion**: Question 3 was declared **genuinely unanswerable from this data**.

---

### Decision 7: Operational Localization vs Root-Cause Mechanism Scope
- **The Observation**: Weybridge district closure times doubled starting in August 2024, while all other districts remained stable.
- **The Assumption & Scope Boundary**: We assumed the `district` field accurately reflects the physical branch office managing the case queue. We proved the drift is **100% localized to Weybridge**.
- **Explicit Scope Boundary**: We explicitly acknowledge that the **underlying physical operational mechanism** (e.g., local staffing turnover, procedural changes, or partner bottlenecks) is **not recorded in this export** and requires local audit.

---
