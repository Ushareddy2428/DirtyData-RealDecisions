﻿# Operational Findings & Answers to Program Leadership

**Author**: Analytics & Data Quality Engineering Team  
**Dataset Analyzed**: Standardized CMS Export (2023–2025)  
**Deliverable**: Comprehensive Analysis of Three Operational Questions  

---

## Executive Summary of Operational Conclusions

```
+-------------------------------------------------------------------------------------------------------------------+
| OPERATIONAL QUESTION SCORECARD                                                                                    |
+---------------------+-----------------------------------------------------------------------+---------------------+
| Question            | Core Operational Finding & Attribution                                | Analytical Status   |
+---------------------+-----------------------------------------------------------------------+---------------------+
| 1. Closure Drift    | Yes. KM Median increased from 34.0d (95% CI: [33, 35]) in 2023 to    | ANSWERED            |
|                     | 43.0d (95% CI: [42, 45]) in 2025 (+9.0 days / +26.5% overall drift).  | (High Confidence)   |
+---------------------+-----------------------------------------------------------------------+---------------------+
| 2. Localization     | 100% localized to Weybridge District starting August 2024.            | ANSWERED            |
|    & Attribution    | Other 3 districts remained completely flat (~30-37 days).             | (Very High Conf.)   |
|                     | Note: Underlying local mechanism is unrecorded & requires local audit.|                     |
+---------------------+-----------------------------------------------------------------------+---------------------+
| 3. Triage Efficacy  | Zero historical baseline (Priority 100% missing pre-Mar 2024).         | CANNOT BE ANSWERED  |
|                     | Priority tag explains zero variance in duration post-2024.            | (Structural Flaw)   |
+---------------------+-----------------------------------------------------------------------+---------------------+
```

---

## Question 1: Have case closure times increased between 2023 and 2025, and if so, by how much?

### The Answer

**Yes, case closure times have increased across the system between 2023 and 2025. Accounting for right-censoring via survival analysis and providing 95% confidence intervals for both means and medians, the magnitude of the drift is quantified as follows:**

1. **Survival-Adjusted Intake Cohort Perspective (Primary Ground Truth)**:
   - When properly accounting for the **751 open cases** still pending at the end of 2025 via **Kaplan-Meier survival estimation**, the system median closure time increased from **34.0 days (95% CI: [33.0, 35.0]) in 2023** to **37.0 days (95% CI: [36.0, 38.0]) in 2024** and **43.0 days (95% CI: [42.0, 45.0]) in 2025**.
   - **Net Increase**: **+9.0 days (+26.5% increase in median duration)**.
   - The 75th percentile (representing tail risk cases) lengthened from **56.0 days in 2023** to **73.0 days in 2025** (+17.0 days / +30.4%).

2. **Empirical Closed-Only Intake Cohort Perspective**:
   - For cases that successfully reached closure within the recording window:
     - **2023 Intake Cohort**: $N = 4,636$ closed cases | **Median: 34.0 days** (95% CI: [33.0, 35.0]) | **Mean: 55.47 days** (95% CI: [53.22, 57.71]) | IQR: 35.0 days | Std: 77.92 days.
     - **2024 Intake Cohort**: $N = 4,535$ closed cases | **Median: 37.0 days** (95% CI: [36.0, 38.0]) | **Mean: 48.32 days** (95% CI: [47.17, 49.46]) | IQR: 38.0 days | Std: 39.24 days.
     - **2025 Intake Cohort**: $N = 3,732$ closed cases | **Median: 38.0 days** (95% CI: [37.0, 39.0]) | **Mean: 49.05 days** (95% CI: [47.81, 50.29]) | IQR: 40.0 days | Std: 38.57 days.
   - *Note on Mean vs Median*: The 2023 cohort mean (55.47 days) is elevated due to long-tail cases that had a full 3 years to close, whereas 2025 closed mean (49.05 days) is artificially depressed because slow-running 2025 cases are censored (still open).

3. **Completion Year Perspective (When Work Was Completed)**:
   - If leadership evaluates cases by the year work finished:
     - **Closed in 2023**: $N = 3,918$ | **Median: 30.0 days** (95% CI: [29.0, 31.0]) | **Mean: 37.24 days** (95% CI: [36.45, 38.04]).
     - **Closed in 2024**: $N = 4,577$ | **Median: 37.0 days** (95% CI: [36.0, 38.0]) | **Mean: 59.38 days** (95% CI: [57.10, 61.66]).
     - **Closed in 2025**: $N = 4,408$ | **Median: 42.0 days** (95% CI: [41.0, 43.0]) | **Mean: 54.81 days** (95% CI: [53.48, 56.13]).

```
Summary Metrics Table for Question 1 (with 95% Confidence Intervals):
+----------------------+----------------------------+----------------------------+----------------------------+
| Analytical View      | 2023 Cohort (95% CI)       | 2024 Cohort (95% CI)       | 2025 Cohort (95% CI)       |
+----------------------+----------------------------+----------------------------+----------------------------+
| KM Survival Median   | 34.0 days [33.0, 35.0]     | 37.0 days [36.0, 38.0]     | 43.0 days [42.0, 45.0]     |
| Empirical Closed Med | 34.0 days [33.0, 35.0]     | 37.0 days [36.0, 38.0]     | 38.0 days [37.0, 39.0]     |
| Empirical Closed Mean| 55.47 days [53.22, 57.71]  | 48.32 days [47.17, 49.46]  | 49.05 days [47.81, 50.29]  |
| Completion Year Med  | 30.0 days [29.0, 31.0]     | 37.0 days [36.0, 38.0]     | 42.0 days [41.0, 43.0]     |
| Completion Year Mean | 37.24 days [36.45, 38.04]  | 59.38 days [57.10, 61.66]  | 54.81 days [53.48, 56.13]  |
+----------------------+----------------------------+----------------------------+----------------------------+
```

### Stated Level of Confidence: High
- **Basis**: Evaluated with both parametric 95% Student-t confidence intervals for means and 1,000-iteration bootstrap 95% confidence intervals for Kaplan-Meier medians.

---

## Question 2: If closure times have changed, what is driving the change?

### The Answer: Operational Localization & Geographic Attribution

**The data proves conclusively that the entire system-wide drift is localized to a single district: Weybridge, beginning abruptly in August 2024 (Q3 2024).**

> [!IMPORTANT]
> **Operational Scope & Mechanism Acknowledgment**: While the data conclusively proves that the slowdown is **geographically localized to Weybridge** and pervasively affects all case categories within that office, **the underlying physical/operational mechanism (e.g., local staff turnover, caseworker burnout, local procedural changes, or partner agency bottlenecks) is not recorded in this export and remains unknown without an on-site local operational audit.**

```
District Median Duration Trajectory (with Bootstrap 95% CIs):
- Ash Hill:        30.0d [28.0, 32.0] -> 30.0d [29.0, 32.0] -> 30.0d [28.0, 33.0]  (FLAT, 0.0% drift)
- Calder Central:  37.0d [35.0, 38.0] -> 37.0d [35.0, 39.0] -> 40.0d [38.0, 42.0]  (STABLE, +3.0d drift)
- Northgate:       31.0d [30.0, 33.0] -> 33.0d [32.0, 35.0] -> 33.0d [32.0, 35.0]  (STABLE, +2.0d drift)
- WEYBRIDGE:       36.0d [34.0, 38.0] -> 50.0d [47.0, 53.0] -> 80.0d [75.5, 85.0]  (SURGE: +44.0d / +122.2% drift!)
```

### Evidence 1: District Decomposition via Kaplan-Meier Survival Analysis

| District | 2023 KM Median (95% CI) | 2024 KM Median (95% CI) | 2025 KM Median (95% CI) | Net Change | 2025 Open Rate (%) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Ash Hill** | 30.0 days [28.0, 32.0] | 30.0 days [29.0, 32.0] | 30.0 days [28.0, 33.0] | **0.0 days (0.0%)** | 11.4% (81 open) |
| **Calder Central** | 37.0 days [35.0, 38.0] | 37.0 days [35.0, 39.0] | 40.0 days [38.0, 42.0] | **+3.0 days (+8.1%)** | 14.3% (217 open) |
| **Northgate** | 31.0 days [30.0, 33.0] | 33.0 days [32.0, 35.0] | 33.0 days [32.0, 35.0] | **+2.0 days (+6.5%)** | 11.3% (133 open) |
| **Weybridge** | **36.0 days [34.0, 38.0]** | **50.0 days [47.0, 53.0]** | **80.0 days [75.5, 85.0]** | <font color="#C53030">**+44.0 days (+122.2%)**</font> | **29.6% (320 open)** |

### Evidence 2: Exact Quarterly Structural Break (August 2024)
- Through **2024 Q2 (June 2024)**, Weybridge tracked the rest of the system closely (~34–36 days).
- In **2024 Q3 (starting August 2024)**, Weybridge durations immediately doubled to **67.5 days**, reaching **77.0 days in 2024 Q4**, and peaking at **80.0+ days in 2025**.
- In contrast, Ash Hill, Calder Central, and Northgate never exceeded 40 days in any quarter.

### Evidence 3: Pervasive Impact Across All Case Types in Weybridge

| Case Category | Other Districts: 2023 Median | Other Districts: 2025 Median | Weybridge: 2023 Median | Weybridge: 2025 Median | Weybridge Drift (%) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Standard** | 29.0 days | 28.0 days | 31.0 days | **60.0 days** | **+93.5%** |
| **Complex** | 70.0 days | 66.0 days | 78.0 days | **138.0 days** | **+76.9%** |
| **Expedited** | 13.0 days | 12.0 days | 13.0 days | **28.0 days** | **+115.4%** |
| **Review** | 38.0 days | 36.0 days | 38.0 days | **79.0 days** | **+107.9%** |
| **Appeal** | 57.0 days | 52.0 days | 57.0 days | **117.0 days** | **+105.3%** |

### Evidence 4: Severe Backlog Concentration in Weybridge
Weybridge accounts for **42.6% of all unresolved open cases across the entire program** (320 out of 751 open cases), despite handling only 24.1% of intake volume. Its open case rate in 2025 reached **29.6%**, compared to 11.3%–14.3% in other districts.

### Stated Level of Confidence: Very High (for District Localization)
- **Basis**: Statistically confirmed across quarterly change points, cross-category comparisons, and survival curves. The root-cause *mechanism* remains explicitly unidentified within the limits of this export.

---

## Question 3: Did the case triage process introduced during 2024 reduce closure times for high-priority cases?

### The Answer

**THIS DATA GENUINELY CANNOT ANSWER THIS QUESTION.**

While leadership intended for the 2024 triage rollout to identify high-priority cases sooner and close them faster, **the dataset possesses four fatal structural and statistical limitations that make it impossible to evaluate triage efficacy.**

---

### Four Fatal Flaws in the Data

#### Flaw 1: Complete Absence of Pre-Intervention Baseline Data
- The `priority` field was **100% unrecorded (5,856 missing records)** from January 1, 2023 through February 29, 2024.
- In March 2024, the field abruptly became mandatory (100% recorded).
- **Statistical Impossibility**: Because there is **zero historical data** on how long high-priority cases took to close prior to March 2024, there is no pre-intervention baseline. One cannot calculate a reduction ($\Delta = \text{Duration}_{\text{post}} - \text{Duration}_{\text{pre}}$) when $\text{Duration}_{\text{pre}}$ is mathematically undefined.

#### Flaw 2: Absence of Triage Process Telemetry
- The dataset contains **no triage metadata**:
  - No `triage_date` (intake-to-triage lag cannot be computed).
  - No indicator of whether a case was triaged by the new process or bypassed it.
  - No field recording caseworker compliance with triage routing.
- The `priority` column is merely a static snapshot label, not an audit of the triage process.

#### Flaw 3: Zero Differentiation Across Priority Levels Post-Rollout
Even when evaluating only post-March 2024 cases where priority was recorded, the data reveals that **High Priority cases were closed no faster than Medium or Low Priority cases**:

```
Post-March 2024 Duration by Recorded Priority (Valid Closed Cases):
+----------------+----------------+----------------+----------------+----------------+
| Priority Band  | Closed Cases   | Median (Days)  | Mean (Days)    | Std (Days)     |
+----------------+----------------+----------------+----------------+----------------+
| High           | 1,124          | 37.0 days      | 47.30 days     | 35.67 days     |
| Low            | 3,333          | 37.0 days      | 49.00 days     | 38.75 days     |
| Medium         | 3,060          | 38.0 days      | 49.58 days     | 41.31 days     |
+----------------+----------------+----------------+----------------+----------------+
```

When controlling for case Category, `priority` explains essentially **zero variance** in closure times:
- `Expedited` cases take **~14 days** whether labeled High (14d), Medium (13d), or Low (14.5d).
- `Standard` cases take **~30–31 days** across High (30d), Medium (31d), and Low (31d).
- `Complex` cases take **~68–74 days** across High (68d), Medium (73d), and Low (74d).

#### Flaw 4: Confounding by the Weybridge Operational Crisis
The rollout of triage in 2024 coincided directly with the operational crisis in Weybridge (where durations doubled starting in August 2024). In Weybridge, High Priority cases had a median duration of **60.5 days**, whereas in Ash Hill they took **28.0 days**. This macro-level district divergence completely obscures any subtle triage impact.

---

### What Would Be Required to Honestly Answer Question 3

To evaluate the triage process with analytical integrity, the program director would need:
1. **Historical Priority Retagging**: Retrospectively applying the 2024 triage criteria to a sample of 2023 cases to establish a valid pre-intervention baseline.
2. **Process Milestone Timestamps**:
   - `triage_timestamp`: To measure time from intake to triage decision.
   - `assignment_timestamp`: To measure queue wait time before caseworker pickup.
3. **Triage Adherence Tracking**: A flag indicating whether the caseworker followed the triage recommendation or re-prioritized the case.
4. **Phased Rollout / Quasi-Experimental Design**: Staggered district-by-district rollout data to perform a rigorous Difference-in-Differences (DiD) econometric analysis.

### Stated Level of Confidence: Absolute Confidence in Unanswerability
- **Basis**: The impossibility is structural and mathematical. Any analyst claiming to demonstrate that triage reduced closure times from this export has fabricated a synthetic baseline or confounded case category with priority.

---
