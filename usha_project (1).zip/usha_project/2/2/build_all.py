# Build script for Problem 2 deliverables
import os
import sys
import json
import re
import pandas as pd
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
import nbformat as nbf

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PACK_DIR = os.path.join(PROJECT_DIR, 'data pack')
RAW_CSV = os.path.join(DATA_PACK_DIR, 'case-export-2023-2025.csv')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'outputs')
FIGURES_DIR = os.path.join(PROJECT_DIR, 'figures')

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)

print('Initialized build_all.py')
